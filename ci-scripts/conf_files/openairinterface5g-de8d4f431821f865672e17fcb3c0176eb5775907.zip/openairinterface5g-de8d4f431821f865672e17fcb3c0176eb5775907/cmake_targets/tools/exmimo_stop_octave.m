n=oarf_get_num_detected_cards;
for i=n-1:0
	oarf_stop(i);
end
