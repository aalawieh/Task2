#!/bin/sh
export UHD_IMAGES_DIR=$SNAP/uhd_images
exec $@
