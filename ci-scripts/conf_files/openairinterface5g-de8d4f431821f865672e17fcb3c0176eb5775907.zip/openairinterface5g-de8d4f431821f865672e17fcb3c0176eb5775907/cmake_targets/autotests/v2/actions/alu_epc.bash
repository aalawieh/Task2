sudo /opt/ltebox/tools/stop_ltebox || true
sudo /opt/ltebox/tools/start_ltebox
